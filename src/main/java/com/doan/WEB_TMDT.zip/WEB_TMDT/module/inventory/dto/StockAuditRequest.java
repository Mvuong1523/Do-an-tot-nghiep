package com.doan.WEB_TMDT.module.inventory.dto;

public class StockAuditRequest {
}
