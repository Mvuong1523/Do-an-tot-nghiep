package com.doan.WEB_TMDT.module.inventory.entity;

public enum TransactionType {
    IMPORT,   // nhập kho
    EXPORT,   // xuất kho
    ADJUST    // điều chỉnh (tuỳ chọn)
}
