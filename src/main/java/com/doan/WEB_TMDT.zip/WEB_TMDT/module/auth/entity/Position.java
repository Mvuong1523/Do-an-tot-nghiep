package com.doan.WEB_TMDT.module.auth.entity;

public enum Position {
    SALE,
    CSKH,
    PRODUCT_MANAGER,
    WAREHOUSE,
    ACCOUNTANT
}
