package com.doan.WEB_TMDT.module.auth.entity;

public enum Status {
    ACTIVE,
    INACTIVE,
    LOCKED
}
