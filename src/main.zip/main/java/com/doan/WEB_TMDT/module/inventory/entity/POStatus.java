package com.doan.WEB_TMDT.module.inventory.entity;

public enum POStatus {
    CREATED,     // vừa tạo, chưa nhập
    CANCELED,// hủy
    RECEIVED
}
