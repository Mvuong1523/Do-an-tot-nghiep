package com.doan.WEB_TMDT.module.payment.entity;

public enum PaymentStatus {
    PENDING, PAID, FAILED, AMOUNT_MISMATCH
}
