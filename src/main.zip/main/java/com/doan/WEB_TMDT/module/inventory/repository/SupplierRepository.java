package com.doan.WEB_TMDT.module.inventory.repository;

import com.doan.WEB_TMDT.module.inventory.entity.Supplier;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface SupplierRepository extends JpaRepository<Supplier, Long> {
    boolean existsByName(String name);
    Optional<Supplier> findByName(String name);
    boolean existsByPhone(String phone);
    boolean existsByEmail(String email);
    boolean existsByTaxCode(String taxCode);
    boolean existsByBankAccount(String bankAcount);
    Optional<Supplier> findByTaxCode(String taxCode);
    Optional<Supplier> findByEmail(String email);
    Optional<Supplier> findByPhone(String phone);
}