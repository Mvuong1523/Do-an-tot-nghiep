package com.doan.WEB_TMDT.module.auth.entity;

public enum Role {
    CUSTOMER,
    ADMIN,
    EMPLOYEE
}
